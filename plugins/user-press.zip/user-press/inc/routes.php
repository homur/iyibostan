<?php

function add_routes( $routes, $callback ) {
}
add_routes('what the hell', 'callback');
